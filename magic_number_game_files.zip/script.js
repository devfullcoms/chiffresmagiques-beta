
$(document).ready(function() {
    console.log("Jeu prêt à jouer !");
});
